import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Cpu, Home, ExternalLink, Smartphone } from "lucide-react"
import Link from "next/link"

export default function TechnologyPage() {
  const techNews = [
    { title: "חברת הייטק ישראלית מפתחת טכנולוגיה חדשנית", time: "לפני 10 דקות", hot: true },
    { title: "השקעה של 100 מיליון דולר בסטארט-אפ ישראלי", time: "לפני 25 דקות", hot: true },
    { title: "פיתוח חדש בתחום הבינה המלאכותית", time: "לפני 45 דקות", hot: false },
    { title: "שיתוף פעולה טכנולוגי בין ישראל לחברות בינלאומיות", time: "לפני שעה", hot: false },
  ]

  const techSites = [
    {
      name: "Geektime",
      url: "https://geektime.co.il",
      description: "אתר החדשות המוביל לטכנולוגיה",
      category: "טכנולוגיה",
    },
    {
      name: "כלכליסט טק",
      url: "https://calcalist.co.il/tech",
      description: "מדור הטכנולוגיה של כלכליסט",
      category: "טכנולוגיה",
    },
    {
      name: "TheMarker Tech",
      url: "https://themarker.com/tech",
      description: "חדשות טכנולוגיה מדה מרקר",
      category: "טכנולוגיה",
    },
    {
      name: "Ynet טכנולוגיה",
      url: "https://ynet.co.il/digital",
      description: "מדור הטכנולוגיה של Ynet",
      category: "טכנולוגיה",
    },
  ]

  const techSectors = [
    { name: "בינה מלאכותית", companies: 198, funding: "$1.9B", icon: "🤖" },
    { name: "סייבר", companies: 180, funding: "$1.8B", icon: "🔒" },
    { name: "פינטק", companies: 245, funding: "$2.1B", icon: "💳" },
    { name: "בריאות דיגיטלית", companies: 156, funding: "$1.5B", icon: "🏥" },
    { name: "מובילטק", companies: 134, funding: "$980M", icon: "📱" },
    { name: "אגריטק", companies: 89, funding: "$650M", icon: "🌱" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/news" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לחדשות</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Cpu className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">טכנולוגיה</h1>
                <p className="text-sm text-gray-600">חדשות הייטק וחדשנות</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Tech Sectors */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="h-5 w-5" />
                  תחומי טכנולוגיה
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {techSectors.map((sector, index) => (
                    <div key={index} className="p-4 bg-blue-50 rounded-lg text-center">
                      <div className="text-3xl mb-2">{sector.icon}</div>
                      <h3 className="font-bold text-gray-900 mb-1">{sector.name}</h3>
                      <div className="text-sm text-gray-600 mb-1">{sector.companies} חברות</div>
                      <div className="font-medium text-blue-600">{sector.funding}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Tech News */}
            <Card>
              <CardHeader>
                <CardTitle>חדשות טכנולוגיה אחרונות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {techNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.hot ? "bg-blue-50 p-3 rounded" : "p-3"}`}
                  >
                    {item.hot && <Badge className="bg-blue-600 text-white text-xs mb-1">חם</Badge>}
                    <h4 className="font-medium leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Tech Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי חדשות טכנולוגיה</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {techSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy/startups" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    סטארט-אפ
                  </Button>
                </Link>
                <Link href="/news/general" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות כלליות
                  </Button>
                </Link>
                <Link href="/economy" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    כלכלה
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
