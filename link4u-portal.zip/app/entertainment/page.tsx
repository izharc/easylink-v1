import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Music, Clock, ExternalLink, Home, Film, Tv, Headphones } from "lucide-react"
import Link from "next/link"

export default function EntertainmentPage() {
  const entertainmentCategories = [
    { name: "טלוויזיה", count: 18, color: "bg-purple-100 text-purple-800", icon: "📺" },
    { name: "קולנוע", count: 15, color: "bg-red-100 text-red-800", icon: "🎬" },
    { name: "מוזיקה", count: 22, color: "bg-blue-100 text-blue-800", icon: "🎵" },
    { name: "תיאטרון", count: 8, color: "bg-green-100 text-green-800", icon: "🎭" },
    { name: "סלבריטיז", count: 12, color: "bg-pink-100 text-pink-800", icon: "⭐" },
    { name: "משחקים", count: 10, color: "bg-orange-100 text-orange-800", icon: "🎮" },
  ]

  const entertainmentSites = [
    {
      name: "Mako",
      url: "https://mako.co.il",
      description: "בידור, טלוויזיה וסלבריטיז",
      category: "בידור כללי",
    },
    {
      name: "Ynet בידור",
      url: "https://ynet.co.il/entertainment",
      description: "מדור הבידור של Ynet",
      category: "בידור כללי",
    },
    {
      name: "Walla! בידור",
      url: "https://entertainment.walla.co.il",
      description: "חדשות בידור וסלבריטיז",
      category: "בידור כללי",
    },
    {
      name: "HOT",
      url: "https://hot.co.il",
      description: "חברת הטלוויזיה הישראלית",
      category: "טלוויזיה",
    },
    {
      name: "YES",
      url: "https://yes.co.il",
      description: "טלוויזיה בלוויין",
      category: "טלוויזיה",
    },
    {
      name: "רשת 13",
      url: "https://13tv.co.il",
      description: "ערוץ 13 - חדשות ובידור",
      category: "טלוויזיה",
    },
    {
      name: "כאן",
      url: "https://kan.org.il",
      description: "התאגיד הישראלי לשידור",
      category: "טלוויזיה",
    },
    {
      name: "זאפה",
      url: "https://zappa-club.co.il",
      description: "מועדוני מוזיקה וקונצרטים",
      category: "מוזיקה",
    },
  ]

  const tvShows = [
    { name: "חדשות 13", time: "20:00", channel: "רשת 13", type: "חדשות" },
    { name: "ארץ נהדרת", time: "21:30", channel: "כאן 11", type: "קומדיה" },
    { name: "הכוכב הבא", time: "22:00", channel: "רשת 13", type: "ריאליטי" },
    { name: "פוליטיקה", time: "23:00", channel: "ערוץ 12", type: "פוליטיקה" },
  ]

  const entertainmentNews = [
    { title: "זוכה 'הכוכב הבא' נחשף - מי זה?", time: "לפני 10 דקות", hot: true },
    { title: "סרט ישראלי חדש זוכה בפרס בקאן", time: "לפני 30 דקות", hot: false },
    { title: "קונצרט ענק של זמר ישראלי בפארק הירקון", time: "לפני שעה", hot: true },
    { title: "סדרה ישראלית חדשה ב-Netflix", time: "לפני שעתיים", hot: false },
    { title: "חתונה של כוכבת ישראלית מפורסמת", time: "לפני 3 שעות", hot: false },
  ]

  const streamingServices = [
    { name: "Netflix", url: "https://netflix.com", icon: "🎬" },
    { name: "Disney+", url: "https://disneyplus.com", icon: "🏰" },
    { name: "Amazon Prime", url: "https://primevideo.com", icon: "📦" },
    { name: "YouTube", url: "https://youtube.com", icon: "📺" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Music className="h-8 w-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">בידור</h1>
                <p className="text-sm text-gray-600">טלוויזיה, קולנוע ומוזיקה</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hot News Banner */}
      <div className="bg-purple-600 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Badge className="bg-white text-purple-600 font-bold">חם</Badge>
            <span className="text-sm font-medium">זוכה 'הכוכב הבא' נחשף - מי זה?</span>
            <span className="text-sm opacity-75">• לפני 10 דקות</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* TV Schedule */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Tv className="h-5 w-5" />
                  לוח שידורים הערב
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {tvShows.map((show, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="text-lg font-bold text-purple-600">{show.time}</div>
                        <div>
                          <h3 className="font-medium">{show.name}</h3>
                          <p className="text-sm text-gray-600">{show.channel}</p>
                        </div>
                      </div>
                      <Badge variant="outline">{show.type}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Entertainment Categories */}
            <Card>
              <CardHeader>
                <CardTitle>קטגוריות בידור</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {entertainmentCategories.map((category, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xl">{category.icon}</span>
                        <Badge className={category.color}>{category.count}</Badge>
                      </div>
                      <span className="font-medium">{category.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Streaming Services */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Film className="h-5 w-5" />
                  שירותי סטרימינג
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {streamingServices.map((service, index) => (
                    <Link key={index} href={service.url} target="_blank" className="group">
                      <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-all hover:scale-105 text-center">
                        <div className="text-3xl mb-2">{service.icon}</div>
                        <h3 className="font-medium group-hover:text-purple-600">{service.name}</h3>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Entertainment Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי בידור מובילים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {entertainmentSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Entertainment News */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-purple-600">
                  <Clock className="h-5 w-5" />
                  חדשות בידור
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {entertainmentNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.hot ? "bg-purple-50 p-2 rounded" : ""}`}
                  >
                    {item.hot && <Badge className="bg-purple-600 text-white text-xs mb-1">חם</Badge>}
                    <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Music & Radio */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Headphones className="h-5 w-5" />
                  מוזיקה ורדיו
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  גלגלצ
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  רדיו תל אביב
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  88FM
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  רדיו דרום
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות כלליות
                  </Button>
                </Link>
                <Link href="/sports" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    ספורט
                  </Button>
                </Link>
                <Link href="/economy" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    כלכלה
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
