import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Newspaper, Clock, ExternalLink, Home, ArrowRight } from "lucide-react"
import Link from "next/link"

export default function NewsPage() {
  const newsCategories = [
    { name: "חדשות כלליות", count: 15, color: "bg-red-100 text-red-800" },
    { name: "פוליטיקה", count: 8, color: "bg-blue-100 text-blue-800" },
    { name: "בטחון", count: 12, color: "bg-green-100 text-green-800" },
    { name: "חברה", count: 6, color: "bg-purple-100 text-purple-800" },
    { name: "טכנולוגיה", count: 9, color: "bg-orange-100 text-orange-800" },
    { name: "בריאות", count: 7, color: "bg-pink-100 text-pink-800" },
  ]

  const newsSites = [
    {
      name: "Ynet",
      url: "https://ynet.co.il",
      description: "אתר החדשות הגדול בישראל",
      category: "חדשות כלליות",
    },
    {
      name: "Walla! חדשות",
      url: "https://news.walla.co.il",
      description: "חדשות, כלכלה ופוליטיקה",
      category: "חדשות כלליות",
    },
    {
      name: "הארץ",
      url: "https://haaretz.co.il",
      description: "עיתון הארץ - חדשות ופוליטיקה",
      category: "פוליטיקה",
    },
    {
      name: "ישראל היום",
      url: "https://israelhayom.co.il",
      description: "העיתון הנפוץ בישראל",
      category: "חדשות כלליות",
    },
    {
      name: "מעריב",
      url: "https://maariv.co.il",
      description: "חדשות ופוליטיקה",
      category: "חדשות כלליות",
    },
    {
      name: "כלכליסט",
      url: "https://calcalist.co.il",
      description: "חדשות כלכלה וטכנולוגיה",
      category: "טכנולוגיה",
    },
    {
      name: "גלובס",
      url: "https://globes.co.il",
      description: "כלכלה ועסקים",
      category: "חדשות כלליות",
    },
    {
      name: "N12",
      url: "https://n12.co.il",
      description: "חדשות כשר 12",
      category: "חדשות כלליות",
    },
  ]

  const breakingNews = [
    { title: "עדכון: פגישת הממשלה בנושא התקציב החדש", time: "לפני 5 דקות", urgent: true },
    { title: "מזג האוויר: גשמים צפויים בצפון הארץ", time: "לפני 15 דקות", urgent: false },
    { title: "בורסה: עליות במניות הטכנולוגיה", time: "לפני 30 דקות", urgent: false },
    { title: "ספורט: ניצחון נבחרת ישראל במשחק הידידות", time: "לפני שעה", urgent: false },
    { title: "תחבורה: עיכובים בקו הרכבת תל אביב-ירושלים", time: "לפני שעתיים", urgent: false },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Newspaper className="h-8 w-8 text-red-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">חדשות</h1>
                <p className="text-sm text-gray-600">עדכונים שוטפים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Breaking News Banner */}
      <div className="bg-red-600 text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Badge className="bg-white text-red-600 font-bold">חדש</Badge>
            <span className="text-sm font-medium">עדכון: פגישת הממשלה בנושא התקציב החדש</span>
            <ArrowRight className="h-4 w-4 animate-pulse" />
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* News Categories */}
            <Card>
              <CardHeader>
                <CardTitle>קטגוריות חדשות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {newsCategories.map((category, index) => {
                    const categoryLinks = {
                      "חדשות כלליות": "/news/general",
                      פוליטיקה: "/news/politics",
                      בטחון: "/news/security",
                      חברה: "/news/society",
                      טכנולוגיה: "/news/technology",
                      בריאות: "/news/health",
                    }

                    return (
                      <Link key={index} href={categoryLinks[category.name] || "#"} className="group">
                        <div className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{category.name}</span>
                            <Badge className={category.color}>{category.count}</Badge>
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* News Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי חדשות מובילים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {newsSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-red-600 hover:bg-red-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Breaking News */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <Clock className="h-5 w-5" />
                  חדשות אחרונות
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {breakingNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.urgent ? "bg-red-50 p-2 rounded" : ""}`}
                  >
                    <div className="flex items-start gap-2">
                      {item.urgent && <Badge className="bg-red-600 text-white text-xs">דחוף</Badge>}
                    </div>
                    <h4 className="font-medium text-sm leading-tight mb-1 mt-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    כלכלה ועסקים
                  </Button>
                </Link>
                <Link href="/sports" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות ספורט
                  </Button>
                </Link>
                <Link href="/entertainment" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בידור ותרבות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
