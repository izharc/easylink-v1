import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Home,
  Newspaper,
  TrendingUp,
  Trophy,
  Music,
  Star,
  Radio,
  Calendar,
  Search,
  Facebook,
  Youtube,
  Mail,
  Globe,
  Smartphone,
  Monitor,
} from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const popularSites = [
    { name: "Google", url: "https://google.com", icon: "🔍", category: "חיפוש" },
    { name: "Facebook", url: "https://facebook.com", icon: "📘", category: "רשתות חברתיות" },
    { name: "YouTube", url: "https://youtube.com", icon: "📺", category: "וידאו" },
    { name: "Gmail", url: "https://gmail.com", icon: "📧", category: "דואר" },
    { name: "Walla!", url: "https://walla.co.il", icon: "📰", category: "חדשות" },
    { name: "Ynet", url: "https://ynet.co.il", icon: "📰", category: "חדשות" },
    { name: "Mako", url: "https://mako.co.il", icon: "📺", category: "בידור" },
    { name: "TheMarker", url: "https://themarker.com", icon: "💰", category: "כלכלה" },
    { name: "Sport5", url: "https://sport5.co.il", icon: "⚽", category: "ספורט" },
    { name: "Instagram", url: "https://instagram.com", icon: "📷", category: "רשתות חברתיות" },
    { name: "WhatsApp Web", url: "https://web.whatsapp.com", icon: "💬", category: "תקשורת" },
    { name: "Netflix", url: "https://netflix.com", icon: "🎬", category: "בידור" },
  ]

  const newsItems = [
    { title: "עדכוני חדשות אחרונות מהארץ והעולם", time: "לפני 15 דקות" },
    { title: "מצב הכלכלה הישראלית - דוח שבועי", time: "לפני שעה" },
    { title: "תוצאות ספורט מהליגות המובילות", time: "לפני 2 שעות" },
    { title: "תחזית מזג האויר לשבוע הקרוב", time: "לפני 3 שעות" },
  ]

  const categories = [
    { name: "חדשות", icon: <Newspaper className="h-5 w-5" />, count: 45 },
    { name: "כלכלה", icon: <TrendingUp className="h-5 w-5" />, count: 23 },
    { name: "ספורט", icon: <Trophy className="h-5 w-5" />, count: 31 },
    { name: "בידור", icon: <Music className="h-5 w-5" />, count: 28 },
    { name: "הורוסקופ", icon: <Star className="h-5 w-5" />, count: 12 },
    { name: "רדיו", icon: <Radio className="h-5 w-5" />, count: 18 },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Home className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">EASYLINK
</h1>
                <p className="text-sm text-gray-600">דף הבית שלך</p>
              </div>
            </div>

            <nav className="hidden md:flex space-x-8 space-x-reverse">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
                בית
              </Link>
              <Link href="/news" className="text-gray-700 hover:text-blue-600 font-medium">
                חדשות
              </Link>
              <Link href="/economy" className="text-gray-700 hover:text-blue-600 font-medium">
                כלכלה
              </Link>
              <Link href="/sports" className="text-gray-700 hover:text-blue-600 font-medium">
                ספורט
              </Link>
              <Link href="/entertainment" className="text-gray-700 hover:text-blue-600 font-medium">
                בידור
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600 font-medium">
                יצירת קשר
              </Link>
            </nav>

            <div className="flex items-center space-x-2 space-x-reverse">
              <Button variant="outline" size="sm">
                <Monitor className="h-4 w-4 ml-2" />
                גרסת מחשב
              </Button>
              <Button variant="outline" size="sm">
                <Smartphone className="h-4 w-4 ml-2" />
                מובייל
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">ברוכים הבאים ל-EASY LINK </h2>
          <p className="text-xl mb-8">הכנס והפוך לדף הבית החדש שלך!</p>
          <p className="text-lg opacity-90 mb-8">פורטל ישראלי המרכז את כל האתרים הפופולאריים והשימושיים במקום אחד</p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto">
            <div className="flex gap-2">
              <Input placeholder="חפש אתרים, חדשות או תוכן..." className="text-right bg-white text-gray-900" />
              <Button className="bg-white text-blue-600 hover:bg-gray-100">
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  קטגוריות תוכן
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {categories.map((category, index) => {
                    const categoryLinks = {
                      חדשות: "/news",
                      כלכלה: "/economy",
                      ספורט: "/sports",
                      בידור: "/entertainment",
                      הורוסקופ: "/horoscope",
                      רדיו: "/radio",
                    }

                    return (
                      <Link key={index} href={categoryLinks[category.name] || "#"} className="group">
                        <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-blue-50 transition-colors">
                          <div className="flex items-center gap-3">
                            {category.icon}
                            <span className="font-medium">{category.name}</span>
                          </div>
                          <Badge variant="secondary">{category.count}</Badge>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Popular Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרים פופולאריים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {popularSites.map((site, index) => (
                    <Link key={index} href={site.url} target="_blank" className="group">
                      <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-all hover:scale-105">
                        <div className="text-center">
                          <div className="text-2xl mb-2">{site.icon}</div>
                          <h3 className="font-medium text-gray-900 group-hover:text-blue-600">{site.name}</h3>
                          <p className="text-xs text-gray-500 mt-1">{site.category}</p>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Tools */}
            <Card>
              <CardHeader>
                <CardTitle>כלים מהירים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Link href="/calendar" className="block">
                    <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                      <Calendar className="h-5 w-5" />
                      לוח שנה
                    </Button>
                  </Link>
                  <Link href="/radio" className="block">
                    <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                      <Radio className="h-5 w-5" />
                      רדיו
                    </Button>
                  </Link>
                  <Link href="/horoscope" className="block">
                    <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                      <Star className="h-5 w-5" />
                      הורוסקופ
                    </Button>
                  </Link>
                  <Link href="/currency" className="block">
                    <Button variant="outline" className="h-16 flex-col gap-2 bg-transparent">
                      <TrendingUp className="h-5 w-5" />
                      מטבעות
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Latest News */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Newspaper className="h-5 w-5" />
                  חדשות אחרונות
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {newsItems.map((item, index) => (
                  <div key={index} className="border-b border-gray-100 pb-3 last:border-b-0">
                    <Link href="/news" className="block hover:text-blue-600">
                      <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                      <p className="text-xs text-gray-500">{item.time}</p>
                    </Link>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Weather Widget */}
            <Card>
              <CardHeader>
                <CardTitle>מזג האוויר</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center">
                  <div className="text-3xl mb-2">☀️</div>
                  <div className="text-2xl font-bold">28°</div>
                  <div className="text-sm text-gray-600">תל אביב</div>
                  <div className="text-xs text-gray-500 mt-2">שמשי, רוחות קלות</div>
                </div>
              </CardContent>
            </Card>

            {/* Horoscope */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  הורוסקופ יומי
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-center">
                    <div className="text-lg font-medium">♌ אריה</div>
                    <p className="text-sm text-gray-600 mt-2">יום מלא בהזדמנויות חדשות. הקשיבו לאינטואיציה שלכם.</p>
                  </div>
                  <Link href="/horoscope" className="block">
                    <Button variant="outline" size="sm" className="w-full bg-transparent">
                      כל המזלות
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle>יצירת קשר</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-sm text-gray-600">יש לכם הערות או הצעות לשיפור?</p>
                <Link href="/contact" className="block">
                  <Button variant="outline" size="sm" className="w-full bg-transparent">
                    צרו קשר
                  </Button>
                </Link>
                <p className="text-xs text-gray-500">דווחו על קישורים שבורים</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-bold text-lg mb-4">LINK4U.CO.IL</h3>
              <p className="text-gray-300 text-sm">הפורטל הישראלי המוביל - דף הבית שלך באינטרנט</p>
            </div>

            <div>
              <h4 className="font-medium mb-3">קישורים מהירים</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link href="/news" className="hover:text-white">
                    חדשות
                  </Link>
                </li>
                <li>
                  <Link href="/economy" className="hover:text-white">
                    כלכלה
                  </Link>
                </li>
                <li>
                  <Link href="/sports" className="hover:text-white">
                    ספורט
                  </Link>
                </li>
                <li>
                  <Link href="/entertainment" className="hover:text-white">
                    בידור
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium mb-3">כתובות משנה</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>
                  <Link href="#" className="hover:text-white">
                    s.DOTANTECH.com
                                      </Link>
                </li>
                <li>
                                  </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    contact.link4u.co.il
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-medium mb-3">עקבו אחרינו</h4>
              <div className="flex gap-3">
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white p-2">
                  <Facebook className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white p-2">
                  <Youtube className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white p-2">
                  <Mail className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
            <p>&copy; {new Date().getFullYear()} LINK4U.CO.IL - כל הזכויות שמורות</p>
            <p className="mt-2">חוויית גלישה מהנה, ידידותית ויעילה</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
