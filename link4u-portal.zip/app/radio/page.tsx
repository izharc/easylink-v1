"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Radio, Home, Play, Volume2, Music, Square, AlertCircle, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function RadioPage() {
  const [currentStation, setCurrentStation] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(50)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const playDemoSound = () => {
    setError(null)
    setCurrentStation("נגן דמו")
    setIsPlaying(true)

    // Simulate playing for demo purposes
    setTimeout(() => {
      setIsPlaying(false)
      setCurrentStation(null)
    }, 5000)
  }

  const stopStation = () => {
    if (audioRef.current) {
      audioRef.current.pause()
      audioRef.current.src = ""
    }
    setIsPlaying(false)
    setCurrentStation(null)
    setError(null)
  }

  const togglePlayPause = () => {
    if (currentStation === "נגן דמו") {
      if (isPlaying) {
        setIsPlaying(false)
      } else {
        playDemoSound()
      }
    }
  }

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ""
      }
    }
  }, [])

  const radioStations = [
    {
      name: "גלגלצ",
      frequency: "91.8 FM",
      description: "תחנת הרדיו הפופולרית בישראל",
      genre: "פופ",
      listeners: "500K+",
      website: "https://glz.co.il",
      available: false,
      reason: "דורש אפליקציה מיוחדת",
    },
    {
      name: "רדיו תל אביב",
      frequency: "102 FM",
      description: "מוזיקה ישראלית ועברית",
      genre: "ישראלית",
      listeners: "300K+",
      website: "https://102fm.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
    {
      name: "88FM",
      frequency: "88 FM",
      description: "מוזיקה אלטרנטיבית ועכשווית",
      genre: "אלטרנטיבי",
      listeners: "200K+",
      website: "https://88fm.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
    {
      name: "נגן דמו",
      frequency: "DEMO",
      description: "נגן דמו לבדיקת הפונקציונליות",
      genre: "דמו",
      listeners: "Demo",
      website: "#",
      available: true,
      reason: "זמין לבדיקה",
    },
    {
      name: "רדיו חיפה",
      frequency: "107.5 FM",
      description: "תחנת הצפון",
      genre: "מגוון",
      listeners: "180K+",
      website: "https://radiohaifa.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
    {
      name: "רדיו ירושלים",
      frequency: "101.3 FM",
      description: "קול ירושלים",
      genre: "מגוון",
      listeners: "120K+",
      website: "https://radiojerusalem.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
    {
      name: "רדיו קול חי",
      frequency: "96.2 FM",
      description: "מוזיקה דתית ומזרחית",
      genre: "דתי",
      listeners: "250K+",
      website: "https://kolhai.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
    {
      name: "רדיו אקו 99",
      frequency: "99 FM",
      description: "מוזיקה רוק ואלטרנטיבית",
      genre: "רוק",
      listeners: "100K+",
      website: "https://eco99.co.il",
      available: false,
      reason: "זמין באתר הרשמי",
    },
  ]

  const genres = [
    { name: "פופ", count: 12, color: "bg-pink-100 text-pink-800" },
    { name: "רוק", count: 8, color: "bg-red-100 text-red-800" },
    { name: "ישראלית", count: 15, color: "bg-blue-100 text-blue-800" },
    { name: "מזרחית", count: 10, color: "bg-orange-100 text-orange-800" },
    { name: "קלאסית", count: 6, color: "bg-purple-100 text-purple-800" },
    { name: "ג'אז", count: 4, color: "bg-green-100 text-green-800" },
  ]

  const nowPlaying = [
    { station: "גלגלצ", song: "שיר חדש - זמר ישראלי", time: "3:45" },
    { station: "רדיו תל אביב", song: "קלאסיקה עברית", time: "2:30" },
    { station: "88FM", song: "Alternative Rock", time: "4:12" },
    { station: "רדיו חיפה", song: "מוזיקה צפונית", time: "3:20" },
  ]

  const popularRadioSites = [
    {
      name: "גלגלצ",
      url: "https://glz.co.il",
      description: "האתר הרשמי של גלגלצ - השמעה חיה",
    },
    {
      name: "רדיו תל אביב 102FM",
      url: "https://102fm.co.il",
      description: "האתר הרשמי - מוזיקה ישראלית",
    },
    {
      name: "88FM",
      url: "https://88fm.co.il",
      description: "מוזיקה אלטרנטיבית - השמעה חיה",
    },
    {
      name: "רדיו קול חי",
      url: "https://kolhai.co.il",
      description: "מוזיקה דתית ומזרחית",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Radio className="h-8 w-8 text-green-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">רדיו</h1>
                <p className="text-sm text-gray-600">תחנות רדיו ישראליות</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Error Message */}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              <span>{error}</span>
              <Button variant="ghost" size="sm" onClick={() => setError(null)} className="mr-auto">
                ✕
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Player Controls */}
      {currentStation && (
        <div className="bg-green-600 text-white py-4">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="sm" className="text-white hover:bg-green-700" onClick={togglePlayPause}>
                  {isPlaying ? <Square className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>
                <div>
                  <div className="font-bold">מתנגן עכשיו: {currentStation}</div>
                  <div className="text-sm opacity-75">{currentStation === "נגן דמו" ? "מצב דמו" : "רדיו חי"}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Volume2 className="h-4 w-4" />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(Number.parseInt(e.target.value))}
                  className="w-20"
                />
                <Button variant="ghost" size="sm" className="text-white hover:bg-green-700" onClick={stopStation}>
                  עצור
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Info Banner */}
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-blue-900 mb-1">מידע חשוב על השמעת רדיו</h3>
                    <p className="text-sm text-blue-800">
                      בשל מגבלות טכניות, השמעה ישירה של תחנות רדיו דורשת הרשאות מיוחדות. לחוויית השמעה מלאה, בקרו באתרים
                      הרשמיים של התחנות.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Now Playing */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Volume2 className="h-5 w-5" />
                  מתנגן עכשיו בתחנות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {nowPlaying.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Play className="h-5 w-5 text-green-600" />
                        <div>
                          <h3 className="font-medium">{item.station}</h3>
                          <p className="text-sm text-gray-600">{item.song}</p>
                        </div>
                      </div>
                      <Badge variant="outline">{item.time}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Radio Stations */}
            <Card>
              <CardHeader>
                <CardTitle>תחנות רדיו ישראליות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {radioStations.map((station, index) => (
                    <div key={index} className={`p-4 bg-white border rounded-lg hover:shadow-md transition-all`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-bold text-lg text-gray-900">{station.name}</h3>
                            <Badge className="bg-green-600 text-white text-xs">{station.frequency}</Badge>
                          </div>
                          <p className="text-gray-600 text-sm mb-2">{station.description}</p>
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline" className="text-xs">
                              {station.genre}
                            </Badge>
                            <span className="text-xs text-gray-500">{station.listeners} מאזינים</span>
                          </div>
                          <p className="text-xs text-blue-600">{station.reason}</p>
                        </div>
                        <div className="ml-4 flex flex-col gap-2">
                          {station.available ? (
                            <Button
                              size="sm"
                              className={`${currentStation === station.name ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}`}
                              onClick={() => {
                                if (currentStation === station.name) {
                                  stopStation()
                                } else {
                                  playDemoSound()
                                }
                              }}
                            >
                              {currentStation === station.name ? (
                                <>
                                  <Square className="h-4 w-4 ml-1" />
                                  עצור
                                </>
                              ) : (
                                <>
                                  <Play className="h-4 w-4 ml-1" />
                                  דמו
                                </>
                              )}
                            </Button>
                          ) : (
                            <Link href={station.website} target="_blank">
                              <Button size="sm" variant="outline" className="bg-transparent">
                                <ExternalLink className="h-4 w-4 ml-1" />
                                אתר
                              </Button>
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Popular Radio Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי רדיו מובילים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {popularRadioSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm">{site.description}</p>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-green-600 hover:bg-green-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Genres */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Music className="h-5 w-5" />
                  ז'אנרים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {genres.map((genre, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-gray-50 rounded hover:bg-gray-100 cursor-pointer"
                    >
                      <span className="font-medium">{genre.name}</span>
                      <Badge className={genre.color}>{genre.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Popular This Week */}
            <Card>
              <CardHeader>
                <CardTitle>פופולרי השבוע</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <h3 className="font-bold">גלגלצ</h3>
                  <p className="text-sm text-gray-600">התחנה הכי פופולרית</p>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <h3 className="font-bold">רדיו תל אביב</h3>
                  <p className="text-sm text-gray-600">מוזיקה ישראלית</p>
                </div>
              </CardContent>
            </Card>

            {/* How to Listen */}
            <Card>
              <CardHeader>
                <CardTitle>איך להאזין?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-gray-600">
                <p>• בקרו באתרים הרשמיים של התחנות</p>
                <p>• הורידו אפליקציות מיוחדות</p>
                <p>• השתמשו ברדיו רגיל</p>
                <p>• נסו שירותי סטרימינג</p>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/entertainment" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בידור
                  </Button>
                </Link>
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
