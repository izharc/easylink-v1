import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { HomeIcon, Building, ExternalLink, TrendingUp, MapPin } from "lucide-react"
import Link from "next/link"

export default function RealEstatePage() {
  const realEstateSites = [
    {
      name: "יד2",
      url: "https://yad2.co.il",
      description: "האתר המוביל למכירת ושכירת דירות",
      category: "מכירה ושכירות",
    },
    {
      name: "הומלס",
      url: "https://homeless.co.il",
      description: "פלטפורמה למציאת דירות",
      category: "שכירות",
    },
    {
      name: "מדלן",
      url: "https://madlan.co.il",
      description: "מידע על מחירי דירות ושכונות",
      category: "מידע ומחירים",
    },
    {
      name: "נדלן.com",
      url: "https://nadlan.com",
      description: "פורטל נדלן מקיף",
      category: "מכירה ושכירות",
    },
    {
      name: "דירה להשכיר",
      url: "https://www.dira4rent.co.il",
      description: "התמחות בשכירות",
      category: "שכירות",
    },
    {
      name: "רמי לוי נדלן",
      url: "https://www.rami-levy.co.il/real-estate",
      description: "שירותי נדלן של רמי לוי",
      category: "שירותים",
    },
  ]

  const propertyTypes = [
    { name: "דירות למכירה", count: 15420, icon: "🏠", avgPrice: "₪1.8M" },
    { name: "דירות להשכרה", count: 8930, icon: "🔑", avgPrice: "₪4,500" },
    { name: "בתים פרטיים", count: 3240, icon: "🏡", avgPrice: "₪3.2M" },
    { name: "משרדים", count: 1850, icon: "🏢", avgPrice: "₪25/מ״ר" },
    { name: "חנויות", count: 920, icon: "🏪", avgPrice: "₪35/מ״ר" },
    { name: "מחסנים", count: 450, icon: "🏭", avgPrice: "₪15/מ״ר" },
  ]

  const cityPrices = [
    { city: "תל אביב", avgPrice: "₪2.8M", change: "+3.2%", positive: true },
    { city: "ירושלים", avgPrice: "₪2.1M", change: "+2.1%", positive: true },
    { city: "חיפה", avgPrice: "₪1.4M", change: "+1.8%", positive: true },
    { city: "באר שבע", avgPrice: "₪980K", change: "+4.1%", positive: true },
    { city: "נתניה", avgPrice: "₪1.6M", change: "+2.5%", positive: true },
    { city: "פתח תקווה", avgPrice: "₪1.9M", change: "+1.9%", positive: true },
  ]

  const realEstateNews = [
    { title: "עליה של 3% במחירי הדירות החודש", time: "לפני 30 דקות", hot: true },
    { title: "תוכנית מחיר למשתכן חדשה אושרה", time: "לפני שעה", hot: true },
    { title: "פרויקט התחדשות עירונית חדש בתל אביב", time: "לפני שעתיים", hot: false },
    { title: "ירידה בביקוש לדירות יוקרה", time: "לפני 3 שעות", hot: false },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/economy" className="flex items-center space-x-2 space-x-reverse">
                <HomeIcon className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לכלכלה</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Building className="h-8 w-8 text-orange-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">נדל"ן</h1>
                <p className="text-sm text-gray-600">מכירה, שכירות ומחירים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* City Prices */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  מחירי דירות לפי ערים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {cityPrices.map((city, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg">
                      <h3 className="font-bold text-lg text-gray-900 mb-2">{city.city}</h3>
                      <div className="text-xl font-bold text-orange-600 mb-1">{city.avgPrice}</div>
                      <div className="flex items-center gap-1">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <span className="text-sm font-medium text-green-600">{city.change}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Property Types */}
            <Card>
              <CardHeader>
                <CardTitle>סוגי נכסים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {propertyTypes.map((type, index) => (
                    <div
                      key={index}
                      className="p-4 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors cursor-pointer"
                    >
                      <div className="text-center">
                        <div className="text-3xl mb-2">{type.icon}</div>
                        <h3 className="font-bold text-gray-900 mb-1">{type.name}</h3>
                        <div className="text-sm text-gray-600 mb-1">{type.count.toLocaleString()} נכסים</div>
                        <div className="font-medium text-orange-600">{type.avgPrice}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Real Estate Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי נדל"ן מובילים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {realEstateSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Real Estate News */}
            <Card>
              <CardHeader>
                <CardTitle className="text-orange-600">חדשות נדל"ן</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {realEstateNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.hot ? "bg-orange-50 p-2 rounded" : ""}`}
                  >
                    {item.hot && <Badge className="bg-orange-600 text-white text-xs mb-1">חם</Badge>}
                    <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Market Trends */}
            <Card>
              <CardHeader>
                <CardTitle>מגמות שוק</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">מחירי מכירה</span>
                    <Badge className="bg-green-600">עולים</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">מחירי שכירות</span>
                    <Badge className="bg-green-600">עולים</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">זמן מכירה ממוצע</span>
                    <Badge className="bg-yellow-600">יציב</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Tools */}
            <Card>
              <CardHeader>
                <CardTitle>כלים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מחשבון משכנתא
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  השוואת מחירים
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מחשבון החזר השקעה
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy/banking" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בנקאות
                  </Button>
                </Link>
                <Link href="/economy/stock-market" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בורסה
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
