import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Home, DollarSign, Calculator, ArrowUpDown } from "lucide-react"
import Link from "next/link"

export default function CurrencyPage() {
  const exchangeRates = [
    { currency: "דולר אמריקאי", code: "USD", rate: "3.65", change: "-0.3%", positive: false, flag: "🇺🇸" },
    { currency: "יורו", code: "EUR", rate: "3.98", change: "+0.8%", positive: true, flag: "🇪🇺" },
    { currency: "פאונד בריטי", code: "GBP", rate: "4.52", change: "+0.2%", positive: true, flag: "🇬🇧" },
    { currency: "ין יפני", code: "JPY", rate: "0.025", change: "-0.1%", positive: false, flag: "🇯🇵" },
    { currency: "פרנק שוויצרי", code: "CHF", rate: "4.12", change: "+0.5%", positive: true, flag: "🇨🇭" },
    { currency: "דולר קנדי", code: "CAD", rate: "2.68", change: "-0.2%", positive: false, flag: "🇨🇦" },
    { currency: "דולר אוסטרלי", code: "AUD", rate: "2.45", change: "+0.4%", positive: true, flag: "🇦🇺" },
    { currency: "קורונה שוודית", code: "SEK", rate: "0.35", change: "+0.1%", positive: true, flag: "🇸🇪" },
  ]

  const cryptoCurrencies = [
    { name: "ביטקוין", code: "BTC", price: "$43,250", change: "+2.5%", positive: true },
    { name: "אתריום", code: "ETH", price: "$2,680", change: "-1.2%", positive: false },
    { name: "ליטקוין", code: "LTC", price: "$72", change: "+0.8%", positive: true },
    { name: "ריפל", code: "XRP", price: "$0.52", change: "+3.1%", positive: true },
  ]

  const popularPairs = [
    { from: "USD", to: "ILS", rate: "3.65" },
    { from: "EUR", to: "ILS", rate: "3.98" },
    { from: "GBP", to: "ILS", rate: "4.52" },
    { from: "ILS", to: "USD", rate: "0.27" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-yellow-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <DollarSign className="h-8 w-8 text-green-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">מטבעות</h1>
                <p className="text-sm text-gray-600">שערי חליפין ומחשבונים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Currency Converter */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  מחשבון המרת מטבעות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">סכום</label>
                    <Input placeholder="100" type="number" />
                  </div>
                  <div className="flex items-center justify-center">
                    <ArrowUpDown className="h-6 w-6 text-gray-400" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">תוצאה</label>
                    <Input placeholder="365 ₪" readOnly className="bg-gray-50" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">מ-</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md">
                      <option>USD - דולר אמריקאי</option>
                      <option>EUR - יורו</option>
                      <option>GBP - פאונד בריטי</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">אל-</label>
                    <select className="w-full p-2 border border-gray-300 rounded-md">
                      <option>ILS - שקל ישראלי</option>
                      <option>USD - דולר אמריקאי</option>
                      <option>EUR - יורו</option>
                    </select>
                  </div>
                </div>
                <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">המר</Button>
              </CardContent>
            </Card>

            {/* Exchange Rates */}
            <Card>
              <CardHeader>
                <CardTitle>שערי חליפין נוכחיים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {exchangeRates.map((rate, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{rate.flag}</span>
                          <div>
                            <h3 className="font-bold text-gray-900">{rate.code}</h3>
                            <p className="text-sm text-gray-600">{rate.currency}</p>
                          </div>
                        </div>
                        <div className="text-left">
                          <div className="text-xl font-bold">₪{rate.rate}</div>
                          <div className={`text-sm font-medium ${rate.positive ? "text-green-600" : "text-red-600"}`}>
                            {rate.change}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Cryptocurrency */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  מטבעות דיגיטליים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {cryptoCurrencies.map((crypto, index) => (
                    <div key={index} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-bold text-gray-900">{crypto.name}</h3>
                          <p className="text-sm text-gray-600">{crypto.code}</p>
                        </div>
                        <div className="text-left">
                          <div className="text-lg font-bold">{crypto.price}</div>
                          <div className={`text-sm font-medium ${crypto.positive ? "text-green-600" : "text-red-600"}`}>
                            {crypto.change}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Popular Pairs */}
            <Card>
              <CardHeader>
                <CardTitle>זוגות פופולאריים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {popularPairs.map((pair, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span className="font-medium">
                      {pair.from}/{pair.to}
                    </span>
                    <span className="font-bold text-green-600">{pair.rate}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Market Status */}
            <Card>
              <CardHeader>
                <CardTitle>סטטוס שוק</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>שוק המטבעות</span>
                    <Badge className="bg-green-600">פתוח</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>קריפטו</span>
                    <Badge className="bg-blue-600">24/7</Badge>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">עדכון אחרון: לפני 2 דקות</div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    כלכלה
                  </Button>
                </Link>
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
