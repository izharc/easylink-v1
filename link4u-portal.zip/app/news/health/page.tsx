import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Home, ExternalLink, Activity } from "lucide-react"
import Link from "next/link"

export default function HealthPage() {
  const healthNews = [
    { title: "מחקר חדש על טיפול בסרטן בישראל", time: "לפני 15 דקות", important: true },
    { title: "קמפיין חיסונים נגד שפעת החל", time: "לפני 30 דקות", important: true },
    { title: "פתיחת מרכז רפואי חדש בצפון", time: "לפני שעה", important: false },
    { title: "מחקר על השפעת התזונה על הבריאות", time: "לפני שעתיים", important: false },
  ]

  const healthSites = [
    {
      name: "משרד הבריאות",
      url: "https://gov.il/he/departments/ministry_of_health",
      description: "האתר הרשמי של משרד הבריאות",
      category: "ממשלתי",
    },
    {
      name: "Ynet בריאות",
      url: "https://ynet.co.il/health",
      description: "מדור הבריאות של Ynet",
      category: "חדשות",
    },
    {
      name: "הארץ בריאות",
      url: "https://haaretz.co.il/health",
      description: "מדור הבריאות של הארץ",
      category: "חדשות",
    },
    {
      name: "מכבי שירותי בריאות",
      url: "https://maccabi4u.co.il",
      description: "קופת חולים מכבי",
      category: "קופת חולים",
    },
  ]

  const healthTopics = [
    { name: "מניעה", description: "חיסונים ובדיקות מניעה", priority: "גבוה", icon: "🛡️" },
    { name: "תזונה", description: "הרגלי תזונה בריאים", priority: "בינוני", icon: "🥗" },
    { name: "פעילות גופנית", description: "חשיבות הספורט לבריאות", priority: "בינוני", icon: "🏃" },
    { name: "בריאות נפש", description: "טיפול פסיכולוגי ופסיכיאטרי", priority: "גבוה", icon: "🧠" },
    { name: "מחלות כרוניות", description: "סוכרת, לחץ דם ועוד", priority: "גבוה", icon: "💊" },
    { name: "בריאות ילדים", description: "בריאות התינוקות והילדים", priority: "גבוה", icon: "👶" },
  ]

  const healthOrganizations = [
    { name: "כללית", members: "4.7M", description: "קופת החולים הגדולה בישראל" },
    { name: "מכבי", members: "2.5M", description: "קופת חולים מכבי" },
    { name: "מאוחדת", members: "1.2M", description: "שירותי בריאות מאוחדת" },
    { name: "לאומית", members: "700K", description: "שירותי בריאות לאומית" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-teal-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/news" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לחדשות</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Heart className="h-8 w-8 text-green-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">בריאות</h1>
                <p className="text-sm text-gray-600">חדשות בריאות ורפואה</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Health Topics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  נושאי בריאות מרכזיים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {healthTopics.map((topic, index) => (
                    <div key={index} className="p-4 bg-green-50 rounded-lg text-center">
                      <div className="text-3xl mb-2">{topic.icon}</div>
                      <h3 className="font-bold text-gray-900 mb-1">{topic.name}</h3>
                      <p className="text-sm text-gray-600 mb-2">{topic.description}</p>
                      <Badge className={topic.priority === "גבוה" ? "bg-red-600" : "bg-yellow-600"}>
                        {topic.priority}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Health News */}
            <Card>
              <CardHeader>
                <CardTitle>חדשות בריאות אחרונות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {healthNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.important ? "bg-green-50 p-3 rounded" : "p-3"}`}
                  >
                    {item.important && <Badge className="bg-green-600 text-white text-xs mb-1">חשוב</Badge>}
                    <h4 className="font-medium leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Health Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי בריאות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {healthSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-green-600 hover:bg-green-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Health Organizations */}
            <Card>
              <CardHeader>
                <CardTitle>קופות חולים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {healthOrganizations.map((org, index) => (
                  <div key={index} className="p-3 bg-green-50 rounded">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-medium text-gray-900">{org.name}</div>
                      <Badge className="bg-green-600">{org.members}</Badge>
                    </div>
                    <div className="text-sm text-gray-600">{org.description}</div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/news/society" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חברה
                  </Button>
                </Link>
                <Link href="/news/general" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות כלליות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
