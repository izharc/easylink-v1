import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, Home, CreditCard, ExternalLink, Percent } from "lucide-react"
import Link from "next/link"

export default function BankingPage() {
  const banks = [
    {
      name: "בנק הפועלים",
      url: "https://poalim.co.il",
      description: "הבנק הגדול בישראל",
      services: ["חשבונות", "משכנתאות", "השקעות"],
    },
    {
      name: "בנק לאומי",
      url: "https://leumi.co.il",
      description: "בנק מוביל בישראל",
      services: ["בנקאות דיגיטלית", "עסקים", "פרטיים"],
    },
    {
      name: "בנק דיסקונט",
      url: "https://discount.co.il",
      description: "בנק מסחרי מוביל",
      services: ["משכנתאות", "חסכונות", "ביטוח"],
    },
    {
      name: "בנק מזרחי טפחות",
      url: "https://mizrahi.co.il",
      description: "בנק פרטי מוביל",
      services: ["ניהול עושר", "עסקים", "דיגיטל"],
    },
    {
      name: "בנק ישראל",
      url: "https://boi.org.il",
      description: "הבנק המרכזי של ישראל",
      services: ["מדיניות מוניטרית", "פיקוח", "מחקר"],
    },
    {
      name: "בנק יהב",
      url: "https://yahav.co.il",
      description: "בנק עובדי המדינה",
      services: ["עובדי ציבור", "פנסיה", "חסכונות"],
    },
  ]

  const bankingServices = [
    { name: "חשבונות עובר ושב", icon: "💳", description: "ניהול חשבון יומיומי" },
    { name: "משכנתאות", icon: "🏠", description: "מימון רכישת דירה" },
    { name: "הלוואות", icon: "💰", description: "הלוואות אישיות ועסקיות" },
    { name: "חסכונות", icon: "🏦", description: "תוכניות חיסכון" },
    { name: "השקעות", icon: "📈", description: "קרנות נאמנות ומניות" },
    { name: "ביטוח", icon: "🛡️", description: "ביטוח חיים ורכוש" },
  ]

  const interestRates = [
    { type: "משכנתא קבועה", rate: "4.2%", period: "לכל התקופה" },
    { type: "משכנתא משתנה", rate: "3.8%", period: "צמודה לפריים" },
    { type: "הלוואה אישית", rate: "6.5%", period: "עד 7 שנים" },
    { type: "פיקדון לזמן קצוב", rate: "2.1%", period: "12 חודשים" },
  ]

  const bankingNews = [
    { title: "בנק ישראל מעלה את הריבית ב-0.25%", time: "לפני 20 דקות", important: true },
    { title: "השקת שירות בנקאות דיגיטלית חדש", time: "לפני שעה", important: false },
    { title: "ירידה בריביות המשכנתאות", time: "לפני שעתיים", important: true },
    { title: "עליה בפיקדונות הציבור", time: "לפני 3 שעות", important: false },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/economy" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לכלכלה</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Building2 className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">בנקאות</h1>
                <p className="text-sm text-gray-600">בנקים ושירותים פיננסיים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Interest Rates */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Percent className="h-5 w-5" />
                  ריביות נוכחיות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {interestRates.map((rate, index) => (
                    <div key={index} className="p-4 bg-blue-50 rounded-lg">
                      <h3 className="font-bold text-lg text-gray-900 mb-1">{rate.type}</h3>
                      <div className="text-2xl font-bold text-blue-600 mb-1">{rate.rate}</div>
                      <p className="text-sm text-gray-600">{rate.period}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Banking Services */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  שירותים בנקאיים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {bankingServices.map((service, index) => (
                    <div
                      key={index}
                      className="p-4 bg-white border rounded-lg hover:shadow-md transition-all cursor-pointer"
                    >
                      <div className="text-center">
                        <div className="text-3xl mb-2">{service.icon}</div>
                        <h3 className="font-bold text-gray-900 mb-1">{service.name}</h3>
                        <p className="text-sm text-gray-600">{service.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Banks */}
            <Card>
              <CardHeader>
                <CardTitle>בנקים בישראל</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {banks.map((bank, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{bank.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{bank.description}</p>
                          <div className="flex flex-wrap gap-1">
                            {bank.services.map((service, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Link href={bank.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Banking News */}
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">חדשות בנקאות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {bankingNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.important ? "bg-blue-50 p-2 rounded" : ""}`}
                  >
                    {item.important && <Badge className="bg-blue-600 text-white text-xs mb-1">חשוב</Badge>}
                    <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Tools */}
            <Card>
              <CardHeader>
                <CardTitle>כלים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מחשבון משכנתא
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מחשבון הלוואה
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  השוואת בנקים
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy/stock-market" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בורסה
                  </Button>
                </Link>
                <Link href="/economy/real-estate" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    נדל"ן
                  </Button>
                </Link>
                <Link href="/economy/insurance" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    ביטוח
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
