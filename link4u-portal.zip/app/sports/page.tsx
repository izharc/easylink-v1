import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Trophy, Clock, ExternalLink, Home, Target, Users } from "lucide-react"
import Link from "next/link"

export default function SportsPage() {
  const sportsCategories = [
    { name: "כדורגל", count: 25, color: "bg-green-100 text-green-800", icon: "⚽" },
    { name: "כדורסל", count: 12, color: "bg-orange-100 text-orange-800", icon: "🏀" },
    { name: "טניס", count: 8, color: "bg-yellow-100 text-yellow-800", icon: "🎾" },
    { name: "שחייה", count: 6, color: "bg-blue-100 text-blue-800", icon: "🏊" },
    { name: "אתלטיקה", count: 10, color: "bg-red-100 text-red-800", icon: "🏃" },
    { name: "ספורט מוטורי", count: 7, color: "bg-gray-100 text-gray-800", icon: "🏎️" },
  ]

  const sportsSites = [
    {
      name: "Sport5",
      url: "https://sport5.co.il",
      description: "אתר הספורט המוביל בישראל",
      category: "ספורט כללי",
    },
    {
      name: "ONE",
      url: "https://one.co.il",
      description: "חדשות ספורט ובידור",
      category: "ספורט כללי",
    },
    {
      name: "ספורט Ynet",
      url: "https://ynet.co.il/sport",
      description: "מדור הספורט של Ynet",
      category: "ספורט כללי",
    },
    {
      name: "ספורט Walla",
      url: "https://sports.walla.co.il",
      description: "חדשות ספורט מ-Walla",
      category: "ספורט כללי",
    },
    {
      name: "התאחדות הכדורגל",
      url: "https://ifa.co.il",
      description: "האתר הרשמי של ההתאחדות",
      category: "כדורגל",
    },
    {
      name: "מכבי תל אביב",
      url: "https://maccabi-tlv.co.il",
      description: 'האתר הרשמי של מכבי ת"א',
      category: "כדורגל",
    },
    {
      name: "הפועל תל אביב",
      url: "https://hapoelta.co.il",
      description: 'האתר הרשמי של הפועל ת"א',
      category: "כדורגל",
    },
    {
      name: "ערוץ הספורט",
      url: "https://sport.co.il",
      description: "ערוץ הספורט הישראלי",
      category: "ספורט כללי",
    },
  ]

  const liveScores = [
    { team1: "מכבי תל אביב", team2: "הפועל חיפה", score1: "2", score2: "1", status: "מסתיים", league: "ליגת העל" },
    { team1: 'בית"ר ירושלים', team2: "מכבי חיפה", score1: "1", score2: "1", status: "דקה 75", league: "ליגת העל" },
    { team1: 'הפועל ת"א', team2: "מכבי נתניה", score1: "-", score2: "-", status: "20:00", league: "ליגת העל" },
    { team1: "נבחרת ישראל", team2: "נבחרת איטליה", score1: "0", score2: "2", status: "מסתיים", league: "ליגת האומות" },
  ]

  const sportsNews = [
    { title: "מכבי תל אביב מנצחת 2-1 את הפועל חיפה", time: "לפני 5 דקות", urgent: true },
    { title: "נבחרת ישראל בכדורסל עולה לשמינית הגמר", time: "לפני 20 דקות", urgent: false },
    { title: "שיא ישראלי חדש בשחייה ל-יעל כהן", time: "לפני שעה", urgent: true },
    { title: "הארכת חוזה למאמן נבחרת הכדורגל", time: "לפני שעתיים", urgent: false },
    { title: "פציעה לכוכב מכבי תל אביב", time: "לפני 3 שעות", urgent: false },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Trophy className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">ספורט</h1>
                <p className="text-sm text-gray-600">חדשות ותוצאות ספורט</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Live Scores Banner */}
      <div className="bg-blue-600 text-white py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-4 overflow-x-auto">
            <Badge className="bg-white text-blue-600 font-bold whitespace-nowrap">תוצאות חיות</Badge>
            {liveScores.slice(0, 2).map((match, index) => (
              <div key={index} className="flex items-center gap-2 whitespace-nowrap">
                <span className="text-sm">
                  {match.team1} {match.score1}-{match.score2} {match.team2}
                </span>
                <Badge variant="outline" className="text-white border-white text-xs">
                  {match.status}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Live Scores */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  תוצאות ומשחקים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {liveScores.map((match, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className="text-xs">
                          {match.league}
                        </Badge>
                        <div className="text-sm">
                          <span className="font-medium">{match.team1}</span>
                          <span className="mx-2 text-xl font-bold">
                            {match.score1} - {match.score2}
                          </span>
                          <span className="font-medium">{match.team2}</span>
                        </div>
                      </div>
                      <Badge className={match.status === "מסתיים" ? "bg-gray-500" : "bg-green-500"}>
                        {match.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Sports Categories */}
            <Card>
              <CardHeader>
                <CardTitle>ענפי ספורט</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {sportsCategories.map((category, index) => (
                    <div
                      key={index}
                      className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xl">{category.icon}</span>
                        <Badge className={category.color}>{category.count}</Badge>
                      </div>
                      <span className="font-medium">{category.name}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Sports Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי ספורט מובילים</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {sportsSites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Sports News */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-600">
                  <Clock className="h-5 w-5" />
                  חדשות ספורט
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {sportsNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.urgent ? "bg-blue-50 p-2 rounded" : ""}`}
                  >
                    {item.urgent && <Badge className="bg-blue-600 text-white text-xs mb-1">חדש</Badge>}
                    <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Teams */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  קבוצות פופולאריות
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מכבי תל אביב
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  הפועל תל אביב
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  בית\"ר ירושלים
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מכבי חיפה
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות כלליות
                  </Button>
                </Link>
                <Link href="/economy" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    כלכלה
                  </Button>
                </Link>
                <Link href="/entertainment" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בידור
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
