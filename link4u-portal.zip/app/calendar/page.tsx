import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Home, Clock, Star } from "lucide-react"
import Link from "next/link"

export default function CalendarPage() {
  const currentDate = new Date()
  const currentMonth = currentDate.toLocaleDateString("he-IL", { month: "long", year: "numeric" })
  const currentDay = currentDate.getDate()

  const holidays = [
    { name: "ראש השנה", date: "15-16 בספטמבר", type: "חג יהודי", days: 2 },
    { name: "יום כיפור", date: "24 בספטמבר", type: "חג יהודי", days: 1 },
    { name: "סוכות", date: "29 בספטמבר", type: "חג יהודי", days: 7 },
    { name: "חנוכה", date: "25 בדצמבר", type: "חג יהודי", days: 8 },
    { name: 'ט"ו בשבט', date: "13 בפברואר", type: "חג יהודי", days: 1 },
    { name: "פורים", date: "14 במרץ", type: "חג יהודי", days: 1 },
  ]

  const events = [
    { title: "יום העצמאות", date: "היום", time: "כל היום", type: "חג לאומי" },
    { title: "פגישת עבודה", date: "מחר", time: "10:00", type: "אישי" },
    { title: "יום הולדת", date: "בעוד 3 ימים", time: "19:00", type: "אישי" },
    { title: "ישיבת צוות", date: "בעוד שבוע", time: "14:00", type: "עבודה" },
  ]

  const monthDays = Array.from({ length: 31 }, (_, i) => i + 1)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Calendar className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">לוח שנה</h1>
                <p className="text-sm text-gray-600">תאריכים וחגים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Current Month */}
            <Card>
              <CardHeader>
                <CardTitle className="text-center">{currentMonth}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {["א", "ב", "ג", "ד", "ה", "ו", "ש"].map((day, index) => (
                    <div key={index} className="text-center font-bold p-2 bg-gray-100 rounded">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-2">
                  {monthDays.map((day) => (
                    <div
                      key={day}
                      className={`text-center p-2 rounded cursor-pointer hover:bg-blue-100 ${
                        day === currentDay ? "bg-blue-600 text-white font-bold" : "bg-gray-50"
                      }`}
                    >
                      {day}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Jewish Holidays */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  חגים יהודיים השנה
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {holidays.map((holiday, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{holiday.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{holiday.date}</p>
                          <Badge variant="outline" className="text-xs">
                            {holiday.type}
                          </Badge>
                        </div>
                        <Badge className="bg-blue-600 text-white">
                          {holiday.days} {holiday.days === 1 ? "יום" : "ימים"}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Today */}
            <Card>
              <CardHeader>
                <CardTitle className="text-center">היום</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-4xl font-bold text-blue-600 mb-2">{currentDay}</div>
                <div className="text-lg font-medium">{currentMonth}</div>
                <div className="text-sm text-gray-600 mt-2">
                  {currentDate.toLocaleDateString("he-IL", { weekday: "long" })}
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Events */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  אירועים קרובים
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {events.map((event, index) => (
                  <div key={index} className="p-3 bg-gray-50 rounded-lg">
                    <h4 className="font-medium text-sm mb-1">{event.title}</h4>
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <span>{event.date}</span>
                      <span>{event.time}</span>
                    </div>
                    <Badge variant="outline" className="text-xs mt-1">
                      {event.type}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>פעולות מהירות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  הוסף אירוע
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  הדפס לוח שנה
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  ייצא ל-Google Calendar
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/horoscope" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    הורוסקופ
                  </Button>
                </Link>
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
