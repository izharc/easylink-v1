import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Home, ExternalLink, Building } from "lucide-react"
import Link from "next/link"

export default function InsurancePage() {
  const insuranceCompanies = [
    {
      name: "כלל ביטוח",
      url: "https://clal.co.il",
      description: "חברת הביטוח הגדולה בישראל",
      services: ["ביטוח חיים", "בריאות", "רכב", "דירה"],
    },
    {
      name: "הפניקס",
      url: "https://hpnx.co.il",
      description: "חברת ביטוח מובילה",
      services: ["פנסיה", "ביטוח חיים", "בריאות"],
    },
    {
      name: "מגדל",
      url: "https://migdal.co.il",
      description: "קבוצת מגדל - ביטוח ופיננסים",
      services: ["פנסיה", "ביטוח", "חיסכון"],
    },
    {
      name: "מנורה מבטחים",
      url: "https://menora.co.il",
      description: "חברת ביטוח וחיסכון",
      services: ["ביטוח חיים", "פנסיה", "בריאות"],
    },
    {
      name: "הראל",
      url: "https://harel.co.il",
      description: "קבוצת הראל - ביטוח והשקעות",
      services: ["ביטוח", "פנסיה", "השקעות"],
    },
    {
      name: "איילון",
      url: "https://ayalon.co.il",
      description: "חברת ביטוח איילון",
      services: ["רכב", "דירה", "עסקים"],
    },
  ]

  const insuranceTypes = [
    { name: "ביטוח חיים", icon: "❤️", description: "הגנה פיננסית למשפחה", avgPrice: "₪150/חודש" },
    { name: "ביטוח בריאות", icon: "🏥", description: "כיסוי רפואי משלים", avgPrice: "₪200/חודש" },
    { name: "ביטוח רכב", icon: "🚗", description: "ביטוח חובה ומקיף", avgPrice: "₪120/חודש" },
    { name: "ביטוח דירה", icon: "🏠", description: "הגנה על הרכוש", avgPrice: "₪80/חודש" },
    { name: "ביטוח נסיעות", icon: "✈️", description: 'כיסוי בחו"ל', avgPrice: "₪50/נסיעה" },
    { name: "ביטוח עסקים", icon: "🏢", description: "הגנה על העסק", avgPrice: "₪300/חודש" },
  ]

  const pensionFunds = [
    { name: "מקפת", assets: "₪45B", members: "180K", returns: "4.2%" },
    { name: "אלטשולר שחם גמל", assets: "₪38B", members: "150K", returns: "3.8%" },
    { name: "הראל פנסיה", assets: "₪42B", members: "170K", returns: "4.1%" },
    { name: "מגדל מקפת", assets: "₪35B", members: "140K", returns: "3.9%" },
  ]

  const insuranceNews = [
    { title: "עליה בפרמיות ביטוח הרכב", time: "לפני 40 דקות", important: true },
    { title: "רפורמה בביטוח הבריאות אושרה", time: "לפני שעה", important: true },
    { title: "תשואות קרנות הפנסיה עולות", time: "לפני שעתיים", important: false },
    { title: "השקת מוצר ביטוח דיגיטלי חדש", time: "לפני 3 שעות", important: false },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/economy" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לכלכלה</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Shield className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">ביטוח</h1>
                <p className="text-sm text-gray-600">חברות ביטוח ופנסיה</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Pension Funds */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  קרנות פנסיה מובילות
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {pensionFunds.map((fund, index) => (
                    <div key={index} className="p-4 bg-blue-50 rounded-lg">
                      <h3 className="font-bold text-lg text-gray-900 mb-2">{fund.name}</h3>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">נכסים מנוהלים:</span>
                          <span className="font-medium">{fund.assets}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">חברים:</span>
                          <span className="font-medium">{fund.members}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">תשואה שנתית:</span>
                          <span className="font-medium text-green-600">{fund.returns}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Insurance Types */}
            <Card>
              <CardHeader>
                <CardTitle>סוגי ביטוח</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {insuranceTypes.map((type, index) => (
                    <div
                      key={index}
                      className="p-4 bg-white border rounded-lg hover:shadow-md transition-all cursor-pointer"
                    >
                      <div className="text-center">
                        <div className="text-3xl mb-2">{type.icon}</div>
                        <h3 className="font-bold text-gray-900 mb-1">{type.name}</h3>
                        <p className="text-sm text-gray-600 mb-2">{type.description}</p>
                        <div className="font-medium text-blue-600">{type.avgPrice}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Insurance Companies */}
            <Card>
              <CardHeader>
                <CardTitle>חברות ביטוח מובילות</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {insuranceCompanies.map((company, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{company.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{company.description}</p>
                          <div className="flex flex-wrap gap-1">
                            {company.services.map((service, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <Link href={company.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Insurance News */}
            <Card>
              <CardHeader>
                <CardTitle className="text-blue-600">חדשות ביטוח</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {insuranceNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.important ? "bg-blue-50 p-2 rounded" : ""}`}
                  >
                    {item.important && <Badge className="bg-blue-600 text-white text-xs mb-1">חשוב</Badge>}
                    <h4 className="font-medium text-sm leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Tools */}
            <Card>
              <CardHeader>
                <CardTitle>כלים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  השוואת ביטוח רכב
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  מחשבון פנסיה
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  בדיקת זכאות
                </Button>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/economy/banking" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בנקאות
                  </Button>
                </Link>
                <Link href="/economy/real-estate" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    נדל"ן
                  </Button>
                </Link>
                <Link href="/economy/stock-market" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בורסה
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
