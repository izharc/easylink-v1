import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, Phone, MapPin, Home, Send } from "lucide-react"
import Link from "next/link"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Mail className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">יצירת קשר</h1>
                <p className="text-sm text-gray-600">נשמח לשמוע מכם</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <Card>
            <CardHeader>
              <CardTitle>שלחו לנו הודעה</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  שם מלא
                </label>
                <Input id="name" placeholder="הכניסו את שמכם המלא" />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  כתובת אימייל
                </label>
                <Input id="email" type="email" placeholder="example@email.com" />
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                  נושא
                </label>
                <Input id="subject" placeholder="נושא ההודעה" />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  הודעה
                </label>
                <Textarea
                  id="message"
                  placeholder="כתבו כאן את הודעתכם, הערותיכם או דיווח על קישורים שבורים..."
                  rows={6}
                />
              </div>

              <Button className="w-full bg-blue-600 hover:bg-blue-700">
                <Send className="h-4 w-4 ml-2" />
                שלח הודעה
              </Button>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>פרטי יצירת קשר</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium">אימייל</p>
                    <p className="text-gray-600">contact@link4u.co.il</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium">טלפון</p>
                    <p className="text-gray-600">03-1234567</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-blue-600" />
                  <div>
                    <p className="font-medium">כתובת</p>
                    <p className="text-gray-600">תל אביב, ישראל</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>למה לפנות אלינו?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">דיווח על קישורים שבורים</p>
                    <p className="text-sm text-gray-600">עזרו לנו לשמור על האתר מעודכן</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">הצעות לשיפור</p>
                    <p className="text-sm text-gray-600">רעיונות לתכנים או אתרים חדשים</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">בעיות טכניות</p>
                    <p className="text-sm text-gray-600">דיווח על תקלות באתר</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                  <div>
                    <p className="font-medium">שאלות כלליות</p>
                    <p className="text-sm text-gray-600">כל שאלה או בקשה</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>כתובות משנה</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="text-sm">
                  <p className="font-medium">s.link4u.co.il</p>
                  <p className="text-gray-600">הגרסה הראשית</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium">m.link4u.co.il</p>
                  <p className="text-gray-600">גרסה מותאמת למובייל</p>
                </div>
                <div className="text-sm">
                  <p className="font-medium">www.link4u.co.il</p>
                  <p className="text-gray-600">כתובת נוספת</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Additional Info */}
        <Card className="mt-8">
          <CardContent className="py-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold mb-2">צוות LINK4U</h3>
              <p className="text-gray-600 max-w-2xl mx-auto">
                אנחנו מקדישים מאמצים לספק לכם חוויית גלישה מהנה, ידידותית ויעילה. הצוות שלנו עובד ללא הפסקה כדי לשמור על
                האתר מעודכן ורלוונטי. נשמח לקבל את הערותיכם והארותיכם לשיפור האתر.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
