import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Home, ExternalLink, Heart } from "lucide-react"
import Link from "next/link"

export default function SocietyPage() {
  const societyNews = [
    { title: "קמפיין חדש לעזרה לקשישים", time: "לפני 15 דקות", important: true },
    { title: "פתיחת מרכז קהילתי חדש בירושלים", time: "לפני 30 דקות", important: false },
    { title: "יוזמה חברתית לסיוע לנזקקים", time: "לפני שעה", important: true },
    { title: "תוכנית חדשה לשילוב בחברה", time: "לפני שעתיים", important: false },
  ]

  const societySites = [
    {
      name: "ידיעות אחרונות - חברה",
      url: "https://ynet.co.il/category/3082",
      description: "חדשות חברה מ-Ynet",
      category: "חברה",
    },
    {
      name: "הארץ - חברה",
      url: "https://haaretz.co.il/news/education",
      description: "מדור החברה של הארץ",
      category: "חברה",
    },
    {
      name: "כלכליסט - חברה",
      url: "https://calcalist.co.il/consumer",
      description: "נושאים חברתיים וצרכנות",
      category: "חברה",
    },
    {
      name: "גלובס - חברה",
      url: "https://globes.co.il/news/category/1",
      description: "חדשות חברה וקהילה",
      category: "חברה",
    },
  ]

  const socialIssues = [
    { name: "דיור ציבורי", description: "פתרונות דיור לאוכלוסיות חלשות", priority: "גבוה" },
    { name: "חינוך", description: "שיפור מערכת החינוך", priority: "גבוה" },
    { name: "בריאות נפש", description: "טיפול בבעיות נפשיות", priority: "בינוני" },
    { name: "קשישים", description: "טיפול באוכלוסיית הקשישים", priority: "גבוה" },
    { name: "נכויות", description: "שילוב אנשים עם מוגבלויות", priority: "בינוני" },
    { name: "עוני", description: "מאבק בעוני ובאי-שוויון", priority: "גבוה" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/news" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לחדשות</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Users className="h-8 w-8 text-pink-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">חברה</h1>
                <p className="text-sm text-gray-600">נושאים חברתיים</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Social Issues */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  נושאים חברתיים מרכזיים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {socialIssues.map((issue, index) => (
                    <div key={index} className="p-4 bg-pink-50 rounded-lg">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-bold text-gray-900">{issue.name}</h3>
                        <Badge
                          className={
                            issue.priority === "גבוה"
                              ? "bg-red-600"
                              : issue.priority === "בינוני"
                                ? "bg-yellow-600"
                                : "bg-green-600"
                          }
                        >
                          {issue.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{issue.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Society News */}
            <Card>
              <CardHeader>
                <CardTitle>חדשות חברה אחרונות</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {societyNews.map((item, index) => (
                  <div
                    key={index}
                    className={`border-b border-gray-100 pb-3 last:border-b-0 ${item.important ? "bg-pink-50 p-3 rounded" : "p-3"}`}
                  >
                    {item.important && <Badge className="bg-pink-600 text-white text-xs mb-1">חשוב</Badge>}
                    <h4 className="font-medium leading-tight mb-1">{item.title}</h4>
                    <p className="text-xs text-gray-500">{item.time}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Society Sites */}
            <Card>
              <CardHeader>
                <CardTitle>אתרי חדשות חברה</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {societySites.map((site, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{site.name}</h3>
                          <p className="text-gray-600 text-sm mb-2">{site.description}</p>
                          <Badge variant="outline" className="text-xs">
                            {site.category}
                          </Badge>
                        </div>
                        <Link href={site.url} target="_blank" className="ml-4">
                          <Button size="sm" className="bg-pink-600 hover:bg-pink-700">
                            <ExternalLink className="h-4 w-4 ml-1" />
                            כניסה
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/news/health" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בריאות
                  </Button>
                </Link>
                <Link href="/news/technology" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    טכנולוגיה
                  </Button>
                </Link>
                <Link href="/news/general" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות כלליות
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
