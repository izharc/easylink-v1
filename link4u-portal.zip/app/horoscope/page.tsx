import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Home, Moon, Sun } from "lucide-react"
import Link from "next/link"

export default function HoroscopePage() {
  const zodiacSigns = [
    {
      name: "מזל טלה",
      dates: "21 במרץ - 19 באפריל",
      symbol: "♈",
      element: "אש",
      prediction: "יום מלא באנרגיה חיובית. הזדמנויות חדשות בדרך.",
    },
    {
      name: "מזל שור",
      dates: "20 באפריל - 20 במאי",
      symbol: "♉",
      element: "אדמה",
      prediction: "יציבות ושלווה. זמן טוב להחלטות כלכליות.",
    },
    {
      name: "מזל תאומים",
      dates: "21 במאי - 20 ביוני",
      symbol: "♊",
      element: "אוויר",
      prediction: "תקשורת מעולה. פגישות חשובות בדרך.",
    },
    {
      name: "מזל סרטן",
      dates: "21 ביוני - 22 ביולי",
      symbol: "♋",
      element: "מים",
      prediction: "רגשות עזים. התמקדו במשפחה ובבית.",
    },
    {
      name: "מזל אריה",
      dates: "23 ביולי - 22 באוגוסט",
      symbol: "♌",
      element: "אש",
      prediction: "זמן לזרוח! הצלחות בתחום המקצועי.",
    },
    {
      name: "מזל בתולה",
      dates: "23 באוגוסט - 22 בספטמבר",
      symbol: "♍",
      element: "אדמה",
      prediction: "ארגון ודיוק יובילו להצלחה. שימו לב לפרטים.",
    },
    {
      name: "מזל מאזניים",
      dates: "23 בספטמבר - 22 באוקטובר",
      symbol: "♎",
      element: "אוויר",
      prediction: "איזון ויופי. זמן טוב לזוגיות ושותפויות.",
    },
    {
      name: "מזל עקרב",
      dates: "23 באוקטובר - 21 בנובמבר",
      symbol: "♏",
      element: "מים",
      prediction: "עומק ותשוקה. גלו סודות חדשים על עצמכם.",
    },
    {
      name: "מזל קשת",
      dates: "22 בנובמבר - 21 בדצמבר",
      symbol: "♐",
      element: "אש",
      prediction: "הרפתקאות ולמידה. הרחיבו את האופקים.",
    },
    {
      name: "מזל גדי",
      dates: "22 בדצמבר - 19 בינואר",
      symbol: "♑",
      element: "אדמה",
      prediction: "שאפתנות ומטרות. הגיע הזמן לטפס לפסגה.",
    },
    {
      name: "מזל דלי",
      dates: "20 בינואר - 18 בפברואר",
      symbol: "♒",
      element: "אוויר",
      prediction: "חדשנות וחברות. רעיונות מקוריים יובילו להצלחה.",
    },
    {
      name: "מזל דגים",
      dates: "19 בפברואר - 20 במרץ",
      symbol: "♓",
      element: "מים",
      prediction: "אינטואיציה וחלומות. הקשיבו לקול הפנימי.",
    },
  ]

  const dailyTips = [
    { title: "מספר המזל היום", content: "7", icon: "🎲" },
    { title: "צבע המזל", content: "כחול", icon: "🎨" },
    { title: "כיוון מזל", content: "מזרח", icon: "🧭" },
    { title: "אבן מזל", content: "אמטיסט", icon: "💎" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4 space-x-reverse">
              <Link href="/" className="flex items-center space-x-2 space-x-reverse">
                <Home className="h-6 w-6 text-blue-600" />
                <span className="text-sm text-gray-600">חזרה לעמוד הראשי</span>
              </Link>
            </div>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Star className="h-8 w-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">הורוסקופ</h1>
                <p className="text-sm text-gray-600">אסטרולוגיה ותחזיות</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Daily Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sun className="h-5 w-5" />
                  טיפים יומיים
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {dailyTips.map((tip, index) => (
                    <div key={index} className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl mb-2">{tip.icon}</div>
                      <h3 className="font-medium text-sm mb-1">{tip.title}</h3>
                      <p className="text-lg font-bold text-purple-600">{tip.content}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Zodiac Signs */}
            <Card>
              <CardHeader>
                <CardTitle>מזלות - תחזית יומית</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {zodiacSigns.map((sign, index) => (
                    <div key={index} className="p-4 bg-white border rounded-lg hover:shadow-md transition-all">
                      <div className="flex items-start gap-4">
                        <div className="text-center">
                          <div className="text-3xl mb-1">{sign.symbol}</div>
                          <Badge variant="outline" className="text-xs">
                            {sign.element}
                          </Badge>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold text-lg text-gray-900 mb-1">{sign.name}</h3>
                          <p className="text-xs text-gray-500 mb-2">{sign.dates}</p>
                          <p className="text-sm text-gray-700">{sign.prediction}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Moon Phase */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Moon className="h-5 w-5" />
                  מופע הירח
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="text-4xl mb-2">🌕</div>
                <h3 className="font-bold">ירח מלא</h3>
                <p className="text-sm text-gray-600 mt-2">זמן של שלמות והגשמה</p>
              </CardContent>
            </Card>

            {/* Lucky Numbers */}
            <Card>
              <CardHeader>
                <CardTitle>מספרי מזל השבוע</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2">
                  {[7, 14, 23, 31, 42, 56].map((number, index) => (
                    <div key={index} className="text-center p-2 bg-purple-100 rounded-lg">
                      <span className="font-bold text-purple-600">{number}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Links */}
            <Card>
              <CardHeader>
                <CardTitle>קישורים מהירים</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/news" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    חדשות
                  </Button>
                </Link>
                <Link href="/entertainment" className="block">
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    בידור
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
